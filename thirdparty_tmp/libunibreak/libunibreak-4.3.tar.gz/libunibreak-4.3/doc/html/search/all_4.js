var searchData=
[
  ['emojidata_2ec_7',['emojidata.c',['../emojidata_8c.html',1,'']]],
  ['emojidef_2ec_8',['emojidef.c',['../emojidef_8c.html',1,'']]],
  ['emojidef_2eh_9',['emojidef.h',['../emojidef_8h.html',1,'']]],
  ['end_10',['end',['../structExtendedPictograpic.html#ae9326370031043f3991d1ff9c1f956f3',1,'ExtendedPictograpic::end()'],['../structGraphemeBreakProperties.html#a75f85f2123204dca4a552498dccb18f0',1,'GraphemeBreakProperties::end()'],['../structLineBreakPropertiesIndex.html#a7a5207276632f772309f8cf2877c9eae',1,'LineBreakPropertiesIndex::end()'],['../structLineBreakProperties.html#af6ff463e88f6c694661aa10222404a14',1,'LineBreakProperties::end()'],['../structWordBreakProperties.html#a7c8c7792e33b8cc829cb881951727d3c',1,'WordBreakProperties::end()']]],
  ['ends_5fwith_11',['ENDS_WITH',['../linebreak_8c.html#a6cc202b1cd8b4ed18d0a7a0a381afcb5',1,'ENDS_WITH():&#160;linebreak.c'],['../linebreak_8c.html#a305f1e46482b23c1c4527ff9afa5a180',1,'ends_with(const char *str, const char *suffix, unsigned suffixLen):&#160;linebreak.c']]],
  ['eos_12',['EOS',['../unibreakdef_8h.html#aadbbc7b02d94a4c18646813ac8d7dec1',1,'unibreakdef.h']]],
  ['ep_5fprop_13',['ep_prop',['../emojidata_8c.html#a265db7d5a2f7209142a553ab305b2861',1,'emojidata.c']]],
  ['extendedpictograpic_14',['ExtendedPictograpic',['../structExtendedPictograpic.html',1,'']]]
];
