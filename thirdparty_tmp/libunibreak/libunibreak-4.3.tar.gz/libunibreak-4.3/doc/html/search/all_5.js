var searchData=
[
  ['flb10leadspace_15',['fLb10LeadSpace',['../structLineBreakContext.html#a0ae5d028c125678a4e48beeaa54f6294',1,'LineBreakContext']]],
  ['flb21ahebrew_16',['fLb21aHebrew',['../structLineBreakContext.html#aae9c8c4e457a7c31683779d095532251',1,'LineBreakContext']]],
  ['flb8azwj_17',['fLb8aZwj',['../structLineBreakContext.html#a54024680e48e955ed6635f51a18b4366',1,'LineBreakContext']]]
];
