var searchData=
[
  ['ub_5fget_5fnext_5fchar_5futf16_160',['ub_get_next_char_utf16',['../unibreakdef_8c.html#adea8e968bcb1389bd071f1088631eac8',1,'ub_get_next_char_utf16(const utf16_t *s, size_t len, size_t *ip):&#160;unibreakdef.c'],['../unibreakdef_8h.html#adea8e968bcb1389bd071f1088631eac8',1,'ub_get_next_char_utf16(const utf16_t *s, size_t len, size_t *ip):&#160;unibreakdef.c']]],
  ['ub_5fget_5fnext_5fchar_5futf32_161',['ub_get_next_char_utf32',['../unibreakdef_8c.html#ad60acf884ef809aaa2b07a47584da27f',1,'ub_get_next_char_utf32(const utf32_t *s, size_t len, size_t *ip):&#160;unibreakdef.c'],['../unibreakdef_8h.html#ad60acf884ef809aaa2b07a47584da27f',1,'ub_get_next_char_utf32(const utf32_t *s, size_t len, size_t *ip):&#160;unibreakdef.c']]],
  ['ub_5fget_5fnext_5fchar_5futf8_162',['ub_get_next_char_utf8',['../unibreakdef_8c.html#a4c74f21cb5f73cf9572f149d26558523',1,'ub_get_next_char_utf8(const utf8_t *s, size_t len, size_t *ip):&#160;unibreakdef.c'],['../unibreakdef_8h.html#a4c74f21cb5f73cf9572f149d26558523',1,'ub_get_next_char_utf8(const utf8_t *s, size_t len, size_t *ip):&#160;unibreakdef.c']]],
  ['ub_5fis_5fextended_5fpictographic_163',['ub_is_extended_pictographic',['../emojidef_8c.html#a538e0aae0f78469f3cd45c53d0a94857',1,'ub_is_extended_pictographic(utf32_t ch):&#160;emojidef.c'],['../emojidef_8h.html#a538e0aae0f78469f3cd45c53d0a94857',1,'ub_is_extended_pictographic(utf32_t ch):&#160;emojidef.c']]],
  ['unibreak_5futf_5ftypes_5fdefined_164',['UNIBREAK_UTF_TYPES_DEFINED',['../unibreakbase_8h.html#ac9149d5a4efc8690a97d07338fc9eb94',1,'unibreakbase.h']]],
  ['unibreak_5fversion_165',['UNIBREAK_VERSION',['../unibreakbase_8h.html#ae61a59be2ea65292900e5cd8699ed3b2',1,'UNIBREAK_VERSION():&#160;unibreakbase.h'],['../unibreakbase_8c.html#a00447944791d6ca9af108a6e14d85470',1,'unibreak_version():&#160;unibreakbase.c'],['../unibreakbase_8h.html#a00447944791d6ca9af108a6e14d85470',1,'unibreak_version():&#160;unibreakbase.c']]],
  ['unibreakbase_2ec_166',['unibreakbase.c',['../unibreakbase_8c.html',1,'']]],
  ['unibreakbase_2eh_167',['unibreakbase.h',['../unibreakbase_8h.html',1,'']]],
  ['unibreakdef_2ec_168',['unibreakdef.c',['../unibreakdef_8c.html',1,'']]],
  ['unibreakdef_2eh_169',['unibreakdef.h',['../unibreakdef_8h.html',1,'']]],
  ['utf16_5ft_170',['utf16_t',['../unibreakbase_8h.html#a4dce96cad338d9281612277b2d80950c',1,'unibreakbase.h']]],
  ['utf32_5ft_171',['utf32_t',['../unibreakbase_8h.html#a4f775bae0642c213be2c526018283c25',1,'unibreakbase.h']]],
  ['utf8_5ft_172',['utf8_t',['../unibreakbase_8h.html#a6103b2105588f239c593e779e605038a',1,'unibreakbase.h']]]
];
