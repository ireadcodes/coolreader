var searchData=
[
  ['namelen_137',['namelen',['../structLineBreakPropertiesLang.html#ab5132ed92c5964a5cfecbb21de206488',1,'LineBreakPropertiesLang']]]
];
