var searchData=
[
  ['wb_5fprop_5fdefault_295',['wb_prop_default',['../wordbreakdata_8c.html#a6141e6bf0cb2beaea11203d7fcbed63a',1,'wordbreakdata.c']]]
];
