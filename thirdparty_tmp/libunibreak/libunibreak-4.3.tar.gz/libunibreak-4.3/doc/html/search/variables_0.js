var searchData=
[
  ['batable_265',['baTable',['../linebreak_8c.html#af99632f769b534cea85cba0c8c94d786',1,'linebreak.c']]]
];
