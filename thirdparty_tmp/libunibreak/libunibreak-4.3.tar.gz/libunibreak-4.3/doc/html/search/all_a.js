var searchData=
[
  ['prh_5fbrk_138',['PRH_BRK',['../linebreak_8c.html#a440c1a7abb9df5e3fc1d27b9a39e3a8da952ca85ab87da029497df2b4195df7d6',1,'linebreak.c']]],
  ['prop_139',['prop',['../structGraphemeBreakProperties.html#ac26f2959ac263c1e51df9cffb8b3ea98',1,'GraphemeBreakProperties::prop()'],['../structLineBreakProperties.html#a46d34ea3f514f8f082d92a441a6665ba',1,'LineBreakProperties::prop()'],['../structWordBreakProperties.html#a30f8834130c9420301b1e94f66cbf4a0',1,'WordBreakProperties::prop()']]]
];
