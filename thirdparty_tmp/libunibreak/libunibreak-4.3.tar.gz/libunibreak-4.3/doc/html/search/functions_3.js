var searchData=
[
  ['lb_5finit_5fbreak_5fcontext_244',['lb_init_break_context',['../linebreak_8c.html#a223651256f2b3a13d2cbf6401527008b',1,'lb_init_break_context(struct LineBreakContext *lbpCtx, utf32_t ch, const char *lang):&#160;linebreak.c'],['../linebreakdef_8h.html#a223651256f2b3a13d2cbf6401527008b',1,'lb_init_break_context(struct LineBreakContext *lbpCtx, utf32_t ch, const char *lang):&#160;linebreak.c']]],
  ['lb_5fprocess_5fnext_5fchar_245',['lb_process_next_char',['../linebreak_8c.html#aec336a0d889b2915c5e764179632ee39',1,'lb_process_next_char(struct LineBreakContext *lbpCtx, utf32_t ch):&#160;linebreak.c'],['../linebreakdef_8h.html#aec336a0d889b2915c5e764179632ee39',1,'lb_process_next_char(struct LineBreakContext *lbpCtx, utf32_t ch):&#160;linebreak.c']]]
];
