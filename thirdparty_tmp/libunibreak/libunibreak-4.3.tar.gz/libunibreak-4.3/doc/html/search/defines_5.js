var searchData=
[
  ['unibreak_5futf_5ftypes_5fdefined_403',['UNIBREAK_UTF_TYPES_DEFINED',['../unibreakbase_8h.html#ac9149d5a4efc8690a97d07338fc9eb94',1,'unibreakbase.h']]],
  ['unibreak_5fversion_404',['UNIBREAK_VERSION',['../unibreakbase_8h.html#ae61a59be2ea65292900e5cd8699ed3b2',1,'unibreakbase.h']]]
];
