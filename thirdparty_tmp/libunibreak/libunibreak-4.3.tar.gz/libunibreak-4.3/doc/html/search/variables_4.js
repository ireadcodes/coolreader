var searchData=
[
  ['gb_5fprop_5fdefault_272',['gb_prop_default',['../graphemebreakdata_8c.html#ac299330e993d25cf51104776bb67addb',1,'graphemebreakdata.c']]]
];
