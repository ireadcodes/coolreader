var searchData=
[
  ['ind_5fbrk_54',['IND_BRK',['../linebreak_8c.html#a440c1a7abb9df5e3fc1d27b9a39e3a8da1f049bd3227f78701750a314bb65b6cc',1,'linebreak.c']]],
  ['init_5fgraphemebreak_55',['init_graphemebreak',['../graphemebreak_8c.html#aaad521cb6d3ab7e6d312ddbff4da869d',1,'init_graphemebreak(void):&#160;graphemebreak.c'],['../graphemebreak_8h.html#aaad521cb6d3ab7e6d312ddbff4da869d',1,'init_graphemebreak(void):&#160;graphemebreak.c']]],
  ['init_5flinebreak_56',['init_linebreak',['../linebreak_8c.html#a57c2b88b7e1277cbba23cfffbc782c4f',1,'init_linebreak(void):&#160;linebreak.c'],['../linebreak_8h.html#a57c2b88b7e1277cbba23cfffbc782c4f',1,'init_linebreak(void):&#160;linebreak.c']]],
  ['init_5fwordbreak_57',['init_wordbreak',['../wordbreak_8c.html#a9be1d054399581a38051e450e8a60482',1,'init_wordbreak(void):&#160;wordbreak.c'],['../wordbreak_8h.html#a9be1d054399581a38051e450e8a60482',1,'init_wordbreak(void):&#160;wordbreak.c']]],
  ['is_5fline_5fbreakable_58',['is_line_breakable',['../linebreak_8c.html#a5761f60559b5ddb61bb095f00c7deb5c',1,'is_line_breakable(utf32_t char1, utf32_t char2, const char *lang):&#160;linebreak.c'],['../linebreak_8h.html#a5761f60559b5ddb61bb095f00c7deb5c',1,'is_line_breakable(utf32_t char1, utf32_t char2, const char *lang):&#160;linebreak.c']]],
  ['is_5fwb3ab_59',['IS_WB3ab',['../wordbreak_8c.html#a092ff924382ce3ce5fabe99255346dda',1,'wordbreak.c']]]
];
