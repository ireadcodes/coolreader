var searchData=
[
  ['test_5fskips_2eh_155',['test_skips.h',['../test__skips_8h.html',1,'']]],
  ['testskipsgrapheme_156',['testSkipsGrapheme',['../test__skips_8h.html#af3e5a058098ff60068a83beb5b193ffc',1,'test_skips.h']]],
  ['testskipsline_157',['testSkipsLine',['../test__skips_8h.html#a06eb4ef4e4a814b364d94113a0f54e2f',1,'test_skips.h']]],
  ['testskipsword_158',['testSkipsWord',['../test__skips_8h.html#a9b7469173833377d3728888f1feed005',1,'test_skips.h']]],
  ['treat_5ffirst_5fchar_159',['treat_first_char',['../linebreak_8c.html#ae684d104e95114e05b172c06730dc310',1,'linebreak.c']]]
];
