var searchData=
[
  ['init_5fgraphemebreak_240',['init_graphemebreak',['../graphemebreak_8c.html#aaad521cb6d3ab7e6d312ddbff4da869d',1,'init_graphemebreak(void):&#160;graphemebreak.c'],['../graphemebreak_8h.html#aaad521cb6d3ab7e6d312ddbff4da869d',1,'init_graphemebreak(void):&#160;graphemebreak.c']]],
  ['init_5flinebreak_241',['init_linebreak',['../linebreak_8c.html#a57c2b88b7e1277cbba23cfffbc782c4f',1,'init_linebreak(void):&#160;linebreak.c'],['../linebreak_8h.html#a57c2b88b7e1277cbba23cfffbc782c4f',1,'init_linebreak(void):&#160;linebreak.c']]],
  ['init_5fwordbreak_242',['init_wordbreak',['../wordbreak_8c.html#a9be1d054399581a38051e450e8a60482',1,'init_wordbreak(void):&#160;wordbreak.c'],['../wordbreak_8h.html#a9be1d054399581a38051e450e8a60482',1,'init_wordbreak(void):&#160;wordbreak.c']]],
  ['is_5fline_5fbreakable_243',['is_line_breakable',['../linebreak_8c.html#a5761f60559b5ddb61bb095f00c7deb5c',1,'is_line_breakable(utf32_t char1, utf32_t char2, const char *lang):&#160;linebreak.c'],['../linebreak_8h.html#a5761f60559b5ddb61bb095f00c7deb5c',1,'is_line_breakable(utf32_t char1, utf32_t char2, const char *lang):&#160;linebreak.c']]]
];
