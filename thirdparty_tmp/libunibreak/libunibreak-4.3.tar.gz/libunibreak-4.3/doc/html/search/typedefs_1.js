var searchData=
[
  ['utf16_5ft_297',['utf16_t',['../unibreakbase_8h.html#a4dce96cad338d9281612277b2d80950c',1,'unibreakbase.h']]],
  ['utf32_5ft_298',['utf32_t',['../unibreakbase_8h.html#a4f775bae0642c213be2c526018283c25',1,'unibreakbase.h']]],
  ['utf8_5ft_299',['utf8_t',['../unibreakbase_8h.html#a6103b2105588f239c593e779e605038a',1,'unibreakbase.h']]]
];
