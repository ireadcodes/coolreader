var searchData=
[
  ['emojidata_2ec_210',['emojidata.c',['../emojidata_8c.html',1,'']]],
  ['emojidef_2ec_211',['emojidef.c',['../emojidef_8c.html',1,'']]],
  ['emojidef_2eh_212',['emojidef.h',['../emojidef_8h.html',1,'']]]
];
