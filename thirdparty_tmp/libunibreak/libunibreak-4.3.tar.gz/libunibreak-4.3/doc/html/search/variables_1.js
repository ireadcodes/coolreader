var searchData=
[
  ['clb30ari_266',['cLb30aRI',['../structLineBreakContext.html#a8d209260a846e51e00b67ce75f1874d7',1,'LineBreakContext']]]
];
