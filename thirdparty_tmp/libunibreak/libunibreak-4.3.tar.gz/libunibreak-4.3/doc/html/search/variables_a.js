var searchData=
[
  ['unibreak_5fversion_294',['unibreak_version',['../unibreakbase_8c.html#a00447944791d6ca9af108a6e14d85470',1,'unibreak_version():&#160;unibreakbase.c'],['../unibreakbase_8h.html#a00447944791d6ca9af108a6e14d85470',1,'unibreak_version():&#160;unibreakbase.c']]]
];
