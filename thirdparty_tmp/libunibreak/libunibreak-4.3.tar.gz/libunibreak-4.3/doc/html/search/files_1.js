var searchData=
[
  ['graphemebreak_2ec_213',['graphemebreak.c',['../graphemebreak_8c.html',1,'']]],
  ['graphemebreak_2eh_214',['graphemebreak.h',['../graphemebreak_8h.html',1,'']]],
  ['graphemebreakdata_2ec_215',['graphemebreakdata.c',['../graphemebreakdata_8c.html',1,'']]],
  ['graphemebreakdef_2eh_216',['graphemebreakdef.h',['../graphemebreakdef_8h.html',1,'']]]
];
