var searchData=
[
  ['get_5fchar_5fgb_5fclass_232',['get_char_gb_class',['../graphemebreak_8c.html#a23ff502a34eac4078bdc0a66a69878f8',1,'graphemebreak.c']]],
  ['get_5fchar_5flb_5fclass_233',['get_char_lb_class',['../linebreak_8c.html#a515d08b5fe8df1025d4404b2dc1eba02',1,'linebreak.c']]],
  ['get_5fchar_5flb_5fclass_5fdefault_234',['get_char_lb_class_default',['../linebreak_8c.html#aa8be95ab8e6ee731e55279772b5aec91',1,'linebreak.c']]],
  ['get_5fchar_5flb_5fclass_5flang_235',['get_char_lb_class_lang',['../linebreak_8c.html#a14b1b543322ce006166f1b55a3c85d2f',1,'linebreak.c']]],
  ['get_5fchar_5fwb_5fclass_236',['get_char_wb_class',['../wordbreak_8c.html#a98212a2ab1759531887f0e1967fe6314',1,'wordbreak.c']]],
  ['get_5flb_5fprop_5flang_237',['get_lb_prop_lang',['../linebreak_8c.html#a66f8fe6c93343261ee729bdbe3f871b8',1,'linebreak.c']]],
  ['get_5flb_5fresult_5flookup_238',['get_lb_result_lookup',['../linebreak_8c.html#ad62e22b9b93a3a2893926b82228791c1',1,'linebreak.c']]],
  ['get_5flb_5fresult_5fsimple_239',['get_lb_result_simple',['../linebreak_8c.html#a32a0952663a6c8a05f2c69674ed36862',1,'linebreak.c']]]
];
