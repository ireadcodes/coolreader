var searchData=
[
  ['get_5fnext_5fchar_5ft_296',['get_next_char_t',['../unibreakdef_8h.html#a645a0969f732500f2dc36ec69271e5c6',1,'unibreakdef.h']]]
];
