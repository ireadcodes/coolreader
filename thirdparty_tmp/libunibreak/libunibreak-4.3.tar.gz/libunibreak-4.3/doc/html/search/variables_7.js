var searchData=
[
  ['prop_289',['prop',['../structGraphemeBreakProperties.html#ac26f2959ac263c1e51df9cffb8b3ea98',1,'GraphemeBreakProperties::prop()'],['../structLineBreakProperties.html#a46d34ea3f514f8f082d92a441a6665ba',1,'LineBreakProperties::prop()'],['../structWordBreakProperties.html#a30f8834130c9420301b1e94f66cbf4a0',1,'WordBreakProperties::prop()']]]
];
