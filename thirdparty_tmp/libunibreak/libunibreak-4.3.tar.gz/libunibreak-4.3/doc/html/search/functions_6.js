var searchData=
[
  ['treat_5ffirst_5fchar_260',['treat_first_char',['../linebreak_8c.html#ae684d104e95114e05b172c06730dc310',1,'linebreak.c']]]
];
