var searchData=
[
  ['lang_273',['lang',['../structLineBreakPropertiesLang.html#ae961b49d11e272adc590cf06e9f6100d',1,'LineBreakPropertiesLang::lang()'],['../structLineBreakContext.html#aecd4a18e4138a674777aac6e7f07be4f',1,'LineBreakContext::lang()']]],
  ['lb_5fprop_5fchinese_274',['lb_prop_Chinese',['../linebreakdef_8c.html#abc245994863c9ae3591f189cce82f549',1,'linebreakdef.c']]],
  ['lb_5fprop_5fdefault_275',['lb_prop_default',['../linebreakdata_8c.html#afa6b57baaf6c687a68a0ce150f423d36',1,'lb_prop_default():&#160;linebreakdata.c'],['../linebreakdef_8h.html#afa6b57baaf6c687a68a0ce150f423d36',1,'lb_prop_default():&#160;linebreakdata.c']]],
  ['lb_5fprop_5fenglish_276',['lb_prop_English',['../linebreakdef_8c.html#a52e2e1a76b9ad70324e0b3667051805c',1,'linebreakdef.c']]],
  ['lb_5fprop_5ffrench_277',['lb_prop_French',['../linebreakdef_8c.html#ac66a1c77300a02cf94c84b256be2e958',1,'linebreakdef.c']]],
  ['lb_5fprop_5fgerman_278',['lb_prop_German',['../linebreakdef_8c.html#a00251cbaa877851c9c3766d26b4d6b7e',1,'linebreakdef.c']]],
  ['lb_5fprop_5findex_279',['lb_prop_index',['../linebreak_8c.html#a5f6f6df49c934134e8fb043ce6230931',1,'linebreak.c']]],
  ['lb_5fprop_5flang_5fmap_280',['lb_prop_lang_map',['../linebreakdef_8c.html#ac273b24d54a00b96e356d52af3ac88b8',1,'lb_prop_lang_map():&#160;linebreakdef.c'],['../linebreakdef_8h.html#ac273b24d54a00b96e356d52af3ac88b8',1,'lb_prop_lang_map():&#160;linebreakdef.c']]],
  ['lb_5fprop_5frussian_281',['lb_prop_Russian',['../linebreakdef_8c.html#a590319e1b2ec7659e90c9b17b33c00f0',1,'linebreakdef.c']]],
  ['lb_5fprop_5fspanish_282',['lb_prop_Spanish',['../linebreakdef_8c.html#ab27f1a9c97b2992d3c1acb5038c00e32',1,'linebreakdef.c']]],
  ['lbccur_283',['lbcCur',['../structLineBreakContext.html#a60c0c91ada87210e50a5ffee4cc6f899',1,'LineBreakContext']]],
  ['lbclast_284',['lbcLast',['../structLineBreakContext.html#ac6c5c4dab09a57c0a38f7a700f16c78c',1,'LineBreakContext']]],
  ['lbcnew_285',['lbcNew',['../structLineBreakContext.html#aa8cfc24887401c50ce6e74558ead05ea',1,'LineBreakContext']]],
  ['lbp_286',['lbp',['../structLineBreakPropertiesIndex.html#ae66348eb79b6d94dbe92e43f934c4dba',1,'LineBreakPropertiesIndex::lbp()'],['../structLineBreakPropertiesLang.html#ae191e36c0e857eecf98a3c35bbd66e46',1,'LineBreakPropertiesLang::lbp()']]],
  ['lbplang_287',['lbpLang',['../structLineBreakContext.html#accc64c7bab810ea1ab8feec3dfe1f281',1,'LineBreakContext']]]
];
